---
title: Android
no_list: true
---

The following languages support client-side gRPC on Android:

- [Java]({{<relref "java">}})
- [Kotlin]({{<relref "kotlin">}})
