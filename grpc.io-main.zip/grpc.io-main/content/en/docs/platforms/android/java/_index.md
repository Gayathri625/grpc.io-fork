---
title: Android Java
layout: prog_lang_home
language: &lang Java
linkTitle: *lang
spelling: cSpell:ignore javadoc
api_path: grpc-java/javadoc
content:
  - learn_more:
    - "[Examples]($src_repo_url/tree/master/examples/android)"
  - reference:
    - "[API](api/)"
  - other:
    - "[Java (non-Android)](/docs/languages/java/)"
    - $src_repo_link
    - "[Download]($src_repo_url#download)"
---
