---
title: Kotlin for Android
layout: prog_lang_home
language: &lang Kotlin
linkTitle: *lang
api_path: https://javadocs.dev/io.grpc/grpc-kotlin-stub/latest
content:
  - learn_more:
    - "[Example]($src_repo_url/tree/master/examples/android)"
  - reference:
    - "[API](api/)"
  - other:
    - "[Kotlin](/docs/languages/kotlin/)"
    - $src_repo_link
    - "[Download](https://search.maven.org/search?q=g:io.grpc%20AND%20grpc-kotlin)"
---
