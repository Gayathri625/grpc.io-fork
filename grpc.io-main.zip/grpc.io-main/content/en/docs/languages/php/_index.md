---
title: PHP
api_path: grpc/LANG/namespace_grpc
prog_lang_home: true
src_repo: https://github.com/grpc/grpc
content:
  - learn_more:
    - "[Examples]($src_repo_url/tree/master/examples/php)"
  - reference:
    - "[API](api/)"
  - other:
    - "[grpc repo]($src_repo_url)"
    - "[Daily builds](daily-builds)"
---

{{% docs/prog-lang-home-content %}}

